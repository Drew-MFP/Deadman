package com.deadman.checkin

import android.content.Context
import android.util.Base64

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("deadman", Context.MODE_PRIVATE)

    var checkInCode: String
        get() = p.getString("checkin", "") ?: ""
        set(v) = p.edit().putString("checkin", v).apply()
    var newLockCode: String
        get() = p.getString("newcode", "") ?: ""
        set(v) = p.edit().putString("newcode", v).apply()
    var limitMinutes: Long
        get() = p.getLong("limit", 20160L) // 14 days
        set(v) = p.edit().putLong("limit", v).apply()
    var lastCheckIn: Long
        get() = p.getLong("last", 0L)
        set(v) = p.edit().putLong("last", v).apply()
    var armed: Boolean
        get() = p.getBoolean("armed", false)
        set(v) = p.edit().putBoolean("armed", v).apply()
    var triggered: Boolean
        get() = p.getBoolean("triggered", false)
        set(v) = p.edit().putBoolean("triggered", v).apply()
    var token: ByteArray?
        get() = p.getString("token", null)?.let { Base64.decode(it, Base64.NO_WRAP) }
        set(v) = p.edit().putString("token", v?.let { Base64.encodeToString(it, Base64.NO_WRAP) }).apply()
}
