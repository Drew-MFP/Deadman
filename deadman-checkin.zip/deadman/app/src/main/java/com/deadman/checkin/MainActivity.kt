package com.deadman.checkin

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.os.Bundle
import android.text.InputType
import android.widget.*
import androidx.work.*
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName
    private lateinit var store: Store
    private lateinit var status: TextView

    private fun field(hint: String, secret: Boolean = true) = EditText(this).apply {
        this.hint = hint
        inputType = if (secret) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_NUMBER
    }

    private fun btn(text: String, onClick: () -> Unit) =
        Button(this).apply { this.text = text; setOnClickListener { onClick() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dpm = getSystemService(DevicePolicyManager::class.java)
        admin = ComponentName(this, AdminReceiver::class.java)
        store = Store(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48) }
        setContentView(ScrollView(this).apply { addView(root) })

        status = TextView(this).apply { textSize = 16f }
        root.addView(status)

        // --- Setup ---
        root.addView(TextView(this).apply { text = "\nSetup"; textSize = 20f })
        val checkIn = field("Check-in code (digits)")
        val newLock = field("New lock PIN used if you miss (min 4 digits)")
        val minutes = field("Time limit in minutes (20160 = 14 days)", secret = false)
        minutes.setText(store.limitMinutes.toString())
        root.addView(checkIn); root.addView(newLock); root.addView(minutes)
        root.addView(btn("Save & start timer") {
            if (!dpm.isDeviceOwnerApp(packageName)) { toast("Not device owner yet"); return@btn }
            if (checkIn.text.length < 4 || newLock.text.length < 4) { toast("Codes need 4+ digits"); return@btn }
            store.checkInCode = checkIn.text.toString()
            store.newLockCode = newLock.text.toString()
            store.limitMinutes = minutes.text.toString().toLongOrNull() ?: 20160L
            store.lastCheckIn = System.currentTimeMillis()
            store.triggered = false
            store.armed = true
            // Token is optional; some ROMs refuse it.
            if (store.token == null) {
                try {
                    val t = ByteArray(32).also { SecureRandom().nextBytes(it) }
                    dpm.setResetPasswordToken(admin, t)
                    store.token = t
                } catch (e: Exception) { /* ignore, fallback method will be used */ }
            }
            WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "deadman", ExistingPeriodicWorkPolicy.REPLACE,
                PeriodicWorkRequestBuilder<CheckWorker>(15, TimeUnit.MINUTES).build()
            )
            refresh(); toast("Saved")
        })

        // --- Test ---
        root.addView(btn("Test now (changes PIN immediately)") {
            if (store.newLockCode.length < 4) { toast("Tap Save first"); return@btn }
            AlertDialog.Builder(this)
                .setTitle("Test PIN change")
                .setMessage("This sets your tablet PIN to the NEW lock PIN right now and locks the screen. You can change it back in Settings afterward. Continue?")
                .setPositiveButton("Yes") { _, _ ->
                    val err = Locker.applyPin(this, store.newLockCode)
                    if (err == null) { toast("Worked"); Locker.lock(this) }
                    else AlertDialog.Builder(this).setTitle("Failed").setMessage(err).setPositiveButton("OK", null).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        })

        // --- Check in ---
        root.addView(TextView(this).apply { text = "\nCheck in"; textSize = 20f })
        val code = field("Enter check-in code")
        root.addView(code)
        root.addView(btn("Check in") {
            if (code.text.toString() == store.checkInCode && store.checkInCode.isNotEmpty()) {
                store.lastCheckIn = System.currentTimeMillis()
                store.triggered = false
                code.setText(""); refresh(); toast("Timer reset")
            } else toast("Wrong code")
        })

        // --- Removal ---
        root.addView(TextView(this).apply { text = "\nRemove"; textSize = 20f })
        val rm = field("Check-in code OR new lock PIN")
        root.addView(rm)
        root.addView(btn("Remove protection (then uninstall)") {
            val c = rm.text.toString()
            if (c.isNotEmpty() && (c == store.checkInCode || c == store.newLockCode)) {
                WorkManager.getInstance(this).cancelUniqueWork("deadman")
                store.armed = false
                if (dpm.isDeviceOwnerApp(packageName)) dpm.clearDeviceOwnerApp(packageName)
                refresh(); toast("Removed. You can uninstall now.")
            } else toast("Wrong code")
        })
        refresh()
    }

    private fun refresh() {
        val owner = dpm.isDeviceOwnerApp(packageName)
        val left = if (store.armed) {
            val ms = store.lastCheckIn + store.limitMinutes * 60_000L - System.currentTimeMillis()
            if (ms <= 0) "due now" else "${ms / 3_600_000L}h ${(ms / 60_000L) % 60}m left"
        } else "not armed"
        status.text = "Device owner: $owner\nTimer: $left\nTriggered: ${store.triggered}"
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
