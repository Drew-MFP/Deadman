package com.deadman.checkin

import android.app.Activity
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.*
import androidx.work.*
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName
    private lateinit var store: Store
    private lateinit var status: TextView

    private fun field(hint: String, number: Boolean = true) = EditText(this).apply {
        this.hint = hint
        inputType = if (number) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT
    }

    private fun btn(text: String, onClick: () -> Unit) =
        Button(this).apply { this.text = text; setOnClickListener { onClick() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dpm = getSystemService(DevicePolicyManager::class.java)
        admin = ComponentName(this, AdminReceiver::class.java)
        store = Store(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48) }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        status = TextView(this).apply { textSize = 16f }
        root.addView(status)

        // --- Setup ---
        root.addView(TextView(this).apply { text = "\nSetup"; textSize = 20f })
        val checkIn = field("Check-in code (digits)")
        val newLock = field("New lock PIN used if you miss (min 4 digits)")
        val minutes = field("Time limit in minutes (20160 = 14 days)")
        minutes.setText(store.limitMinutes.toString())
        root.addView(checkIn); root.addView(newLock); root.addView(minutes)
        root.addView(btn("Save & start timer") {
            if (!dpm.isDeviceOwnerApp(packageName)) { toast("Not device owner yet. See README."); return@btn }
            if (checkIn.text.length < 4 || newLock.text.length < 4) { toast("Codes need 4+ digits"); return@btn }
            store.checkInCode = checkIn.text.toString()
            store.newLockCode = newLock.text.toString()
            store.limitMinutes = minutes.text.toString().toLongOrNull() ?: 20160L
            store.lastCheckIn = System.currentTimeMillis()
            store.triggered = false
            store.armed = true
            if (store.token == null) {
                val t = ByteArray(32).also { SecureRandom().nextBytes(it) }
                dpm.setResetPasswordToken(admin, t)
                store.token = t
            }
            WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "deadman", ExistingPeriodicWorkPolicy.REPLACE,
                PeriodicWorkRequestBuilder<CheckWorker>(15, TimeUnit.MINUTES).build()
            )
            refresh(); toast("Saved")
        })
        root.addView(btn("Activate reset token (confirm current lock)") {
            val i = getSystemService(KeyguardManager::class.java).createConfirmDeviceCredentialIntent(null, null)
            if (i != null) startActivityForResult(i, 1) else refresh()
        })

        // --- Check in ---
        root.addView(TextView(this).apply { text = "\nCheck in"; textSize = 20f })
        val code = field("Enter check-in code")
        root.addView(code)
        root.addView(btn("Check in") {
            if (code.text.toString() == store.checkInCode && store.checkInCode.isNotEmpty()) {
                store.lastCheckIn = System.currentTimeMillis()
                code.setText(""); refresh(); toast("Timer reset")
            } else toast("Wrong code")
        })

        // --- Removal ---
        root.addView(TextView(this).apply { text = "\nRemove"; textSize = 20f })
        val rm = field("Check-in code OR new lock PIN")
        root.addView(rm)
        root.addView(btn("Remove protection (then uninstall)") {
            val c = rm.text.toString()
            if (c.isNotEmpty() && (c == store.checkInCode || c == store.newLockCode)) {
                WorkManager.getInstance(this).cancelUniqueWork("deadman")
                store.armed = false
                if (dpm.isDeviceOwnerApp(packageName)) dpm.clearDeviceOwnerApp(packageName)
                refresh(); toast("Removed. You can uninstall now.")
            } else toast("Wrong code")
        })
        refresh()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        refresh()
    }

    private fun refresh() {
        val owner = dpm.isDeviceOwnerApp(packageName)
        val tokenActive = owner && store.token != null && try { dpm.isResetPasswordTokenActive(admin) } catch (e: Exception) { false }
        val left = if (store.armed) {
            val ms = store.lastCheckIn + store.limitMinutes * 60_000L - System.currentTimeMillis()
            if (ms <= 0) "due now" else "${ms / 3_600_000L}h ${(ms / 60_000L) % 60}m left"
        } else "not armed"
        status.text = "Device owner: $owner\nToken active: $tokenActive\nTimer: $left\nTriggered: ${store.triggered}"
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
