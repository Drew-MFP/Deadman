package com.deadman.checkin

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object Scheduler {
    private fun pending(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 1, Intent(ctx, AlarmReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun setAt(ctx: Context, at: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(pending(ctx))
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx))
    }

    fun schedule(ctx: Context) {
        val s = Store(ctx)
        if (!s.armed || s.triggered) { cancel(ctx); return }
        setAt(ctx, maxOf(s.lastCheckIn + s.limitMinutes * 60_000L, System.currentTimeMillis() + 1_000L))
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx))
    }

    fun runIfDue(ctx: Context) {
        val s = Store(ctx)
        if (!s.armed || s.triggered) return
        if (System.currentTimeMillis() < s.lastCheckIn + s.limitMinutes * 60_000L) { schedule(ctx); return }
        val err = Locker.applyPin(ctx, s.newLockCode)
        if (err == null) {
            s.triggered = true
            Locker.lock(ctx)
        } else {
            setAt(ctx, System.currentTimeMillis() + 5 * 60_000L) // retry
        }
    }
}
