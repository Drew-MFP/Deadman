package com.deadman.checkin

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class CheckWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val s = Store(applicationContext)
        if (!s.armed || s.triggered) return Result.success()

        val deadline = s.lastCheckIn + s.limitMinutes * 60_000L
        if (System.currentTimeMillis() < deadline) return Result.success()

        val dpm = applicationContext.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(applicationContext, AdminReceiver::class.java)
        val token = s.token ?: return Result.success()

        try {
            if (dpm.resetPasswordWithToken(admin, s.newLockCode, token, 0)) {
                dpm.lockNow()
                s.triggered = true
            }
        } catch (e: Exception) {
            return Result.retry()
        }
        return Result.success()
    }
}
