package com.deadman.checkin

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class CheckWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        Scheduler.runIfDue(applicationContext)
        return Result.success()
    }
}
