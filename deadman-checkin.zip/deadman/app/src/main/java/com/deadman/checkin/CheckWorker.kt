package com.deadman.checkin

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class CheckWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val s = Store(applicationContext)
        if (!s.armed || s.triggered) return Result.success()

        val deadline = s.lastCheckIn + s.limitMinutes * 60_000L
        if (System.currentTimeMillis() < deadline) return Result.success()

        val err = Locker.applyPin(applicationContext, s.newLockCode)
        if (err == null) {
            s.triggered = true
            Locker.lock(applicationContext)
            return Result.success()
        }
        return Result.retry()
    }
}
